
/* Revision 2 */

#ifndef robotOnLine_h
#define robotOnLine_h

#include "Arduino.h"
#include <FunctionalInterrupt.h>
#include "E32_PC0.h"  //to controll ESP32 pulse counter module (unit 0)
#include "E32_PC1.h"  //to controll ESP32 pulse counter module (unit 1)

extern byte autoDrive(byte);  //to check the sensors and do autoDrive related tasks
//extern void _config();  // private function to configure the pins

void IRAM_ATTR _think(); // private function to handle interrupts triggered by the IR sensors, used by the auto driving functionality
void IRAM_ATTR onTimer();

class robotOnLine
{
  public:
  
    //functions to edit pin configuration, must be called before begin()
    void editWheelPin(uint8_t , uint8_t );
    void editMotorPin(uint8_t , uint8_t , uint8_t , uint8_t );
    void editUltrasonicPin(uint8_t , uint8_t );
    void editSensorPin(uint8_t , uint8_t , uint8_t , uint8_t , uint8_t , uint8_t , uint8_t );

    void setStopDistance(byte );

    void endAutoDrive();  // detaches the interruptions that call the _think() function
    void beginAutoDrive();  // attaches the interruptions that call the _think() function
    void begin(); // Does the pin and PWM configuration

    byte distance();  
    void turnLeft(uint16_t ); //turns n degrees
    void turnRight(uint16_t );  //turns n degrees
    
    //info you can send: 1 do half turn, 2 turn left'line, 3 turn right'line, 4 forward, 5 reverse
    byte autoDrive(byte); //returns 1 when multiple lines or obstacle found, returns 2 if obstacle is found
    void steerLeft(byte ); //turns very slightly without stopping or reversing any of the wheels
    void steerRight(byte );  //turns very slightly without stopping or reversing any of the wheels
    void rotateLeft(byte ); //keeps turning at n Dutty
    void rotateRight(byte );  //keeps turning at n Dutty
    void stopMotors();  //self explanatory
    void forward(byte );  //self explanatory
    void reverse(byte );  //self explanatory
    void leftWheel(short ); //controls the left wheel, positive values make it move forward and vice-versa, a 0 stops the motors. Ranges from -255 to 255
    void rightWheel(short );  //controls the right wheel, positive values make it move forward and vice-versa, a 0 stops the motors. Ranges from -255 to 255

    //rev2 added
    void decelerate(byte );
    void decelerateSide(bool ,byte );
    void accelerate(byte );
    void accelerateSide(bool ,byte );

    //for sensors
    void clearEncoderCount(); //self explanatory
    static int16_t getLeftEncoderCount();  //self explanatory
    static int16_t getRightEncoderCount(); //self explanatory
    byte checkSensors();
    void disableCLP();  // disables the checking of the CLP switch of the autodrive functionality
    void disableNear(); // disables the checking of the Near sensor of the autodrive functionality
    void disableUltrasonic(); // disables the checking of the ultrasonic sensor of the autodrive functionality
    void setSpeeds(byte ,byte ,byte); // sets the fastest, medium and lower speeds used by the various functions, including the autodrive functionality
    void noLineDelay(uint );  // it's the delay (in ms) of how much time the robot will keep moving after acknowledging that there isn't a line to follow, very useful since the line may be between two sensors at a moment.
    
    bool readCLP();
    bool readNear();
    bool readS1();
    bool readS2();
    bool readS3();
    bool readS4();
    bool readS5();

    volatile static byte _LS2;
    volatile static byte _MS3;
    volatile static byte _RS4;
    volatile static byte _CLP;
    volatile static int8_t _speedAdjR;
    volatile static int8_t _speedAdjL;

    volatile static byte _wheelL;
    volatile static byte _wheelR;
    
    //added in rev2 
    void forwardRPS(float );
    void reverseRPS(float );
    void rotateRightRPS(float );
    void rotateLeftRPS(float );

    void forwardRPM(float );
    void reverseRPM(float );
    void rotateRightRPM(float );
    void rotateLeftRPM(float );

    void forwardMS(float );
    void reverseMS(float );
    void rotateRightMS(float );
    void rotateLeftMS(float );

    void enableRPS();

    float getLeftRPS();
    float getRightRPS();
    float getLeftRPM();
    float getRightRPM();
    float getLeftMS();
    float getRightMS();
    
    void moveAt(byte, byte , float );

    //added in rev2 
    volatile static byte _mov;
    volatile static byte _rPWM;
    volatile static byte _lPWM;
    volatile static byte _minSpeed;
    volatile static bool _bootFlag;
    volatile static uint _speedRPS;
    volatile static bool _canAdjustRPS;
    volatile static bool _RPSenabled;

    volatile static uint leftRPS;
    volatile static uint rightRPS;

  private:

  
    bool _checkMinSpeed();
    void _config();
    bool _ec(); //extra-check, private function used by auto driving functionality

    //Next three variables are self explanatory, they are changed by the functions mentioned before
    bool _disableUltrasonicSensor = 0;  
    bool _disableNearSensor = 0;  
    bool _disableCLPSensor = 0; 

    bool _maneuver = 1; // to know if the robot did a maneuver, used to adjust the wheels speed in the auto driving functionality
    bool _lastEncoderOffsetMatch = 0;
    bool _fixDirAlways = 1;
    byte _encoderAhead = 0;
    bool _encoderOsc = 0;
    
    byte _LLS1 = 25;
    byte _RRS5 = 34;
    byte _Near = 36;

    //motor pins IN1&IN2 right engine
    byte _IN1 = 4; 
    byte _IN2 = 16;
    //IN3&IN4 left engine
    byte _IN3 = 17;
    byte _IN4 = 18;
    //IR optical interruption sensor pins, 20 wholes
    /* byte _wheelL = 26;
    byte _wheelR = 27; */

    byte _trig = 14;
    byte _echo = 12;

    byte _lastLinePos=0; // tells which sensor "saw" the line last time 1 to 5
    byte _stopDistance = 9;

    byte _fastSpeed = 255;
    byte _averageSpeed = 200;
    byte _slowSpeed = 180;

    uint _dif=750;  // time it will take to stop the robot after no line is found
    uint _invDel=100; //delay to wait before inverting motors polarity

};




#endif